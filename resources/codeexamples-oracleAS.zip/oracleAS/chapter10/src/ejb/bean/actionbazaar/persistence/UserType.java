package actionbazaar.persistence;
public enum UserType {SELLER, BUYER, ADMIN, CLERK};