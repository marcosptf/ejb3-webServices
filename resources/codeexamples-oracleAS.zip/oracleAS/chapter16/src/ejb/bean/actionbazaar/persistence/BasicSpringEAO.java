package actionbazaar.persistence.eao;

import org.springframework.orm.jpa.support.JpaDaoSupport;

public abstract class BasicSpringEAO extends JpaDaoSupport {

}
