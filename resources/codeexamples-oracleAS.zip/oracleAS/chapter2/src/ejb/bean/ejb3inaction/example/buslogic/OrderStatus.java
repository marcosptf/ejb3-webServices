package ejb3inaction.example.buslogic;

public enum OrderStatus {
    NEW, COMPLETE, BILLING_FAILED, SHIPPED
};