package actionbazaar.persistence;
public enum BidStatus {NEW, WITHDRAWN, WINNER, CANCELLED};