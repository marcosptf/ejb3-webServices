@javax.xml.bind.annotation.XmlSchema(namespace = "http://actionbazaar.com/xml")
package actionbazaar.buslogic;
