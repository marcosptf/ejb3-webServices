package com.ejb3inaction.actionbazaar.persistence;

public enum BidderStatus {
	NEW, ACTIVE, SILVER, GOLD, INACTIVE
};