-- Drop action bazaar tables.

DROP TABLE BIDS IF EXISTS;