package com.ejb3inaction.actionbazaar.persistence;

public enum OrderStatus {
	NEW, COMPLETE, BILLING_FAILED, SHIPPED
};