- Download and setup the Spring framework from http://www.springframework.org.
- Setup an environment variable named SPRING_HOME pointing to the root of the spring framework
  directory.
- Run the ant script under the chapter16 directory.
- If the JBoss application server is running, make sure the new application is deployed.
- If the application server is not running, start it.
- Go to http://localhost:8080/chapter16 and run the application.