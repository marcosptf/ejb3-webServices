package com.ejb3inaction.actionbazaar.persistence;

public enum BidStatus {
	NEW, WITHDRAWN, WINNER, CANCELLED
};