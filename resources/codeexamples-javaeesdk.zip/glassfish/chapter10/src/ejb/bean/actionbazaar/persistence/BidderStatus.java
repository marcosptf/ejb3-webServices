package actionbazaar.persistence;
public enum BidderStatus {NEW, ACTIVE, SILVER, GOLD, INACTIVE};